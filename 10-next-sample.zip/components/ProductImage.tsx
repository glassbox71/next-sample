export default function ProductImage({ image }: { image: string }) {
  return <img src={image} width={300} />;
}
